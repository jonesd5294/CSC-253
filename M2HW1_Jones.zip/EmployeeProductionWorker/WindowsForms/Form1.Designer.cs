﻿
namespace WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.idNumTextBox = new System.Windows.Forms.TextBox();
            this.shiftTextBox = new System.Windows.Forms.TextBox();
            this.hourlyPayTextBox = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.shiftLabel = new System.Windows.Forms.Label();
            this.payLabel = new System.Windows.Forms.Label();
            this.enterButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.nameOutLabel = new System.Windows.Forms.Label();
            this.idOutLabel = new System.Windows.Forms.Label();
            this.shiftOutLabel = new System.Windows.Forms.Label();
            this.payOutLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.empNameLabel = new System.Windows.Forms.Label();
            this.empIdLabel = new System.Windows.Forms.Label();
            this.empShiftLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(182, 39);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 0;
            // 
            // idNumTextBox
            // 
            this.idNumTextBox.Location = new System.Drawing.Point(182, 65);
            this.idNumTextBox.Name = "idNumTextBox";
            this.idNumTextBox.Size = new System.Drawing.Size(100, 20);
            this.idNumTextBox.TabIndex = 1;
            // 
            // shiftTextBox
            // 
            this.shiftTextBox.Location = new System.Drawing.Point(182, 95);
            this.shiftTextBox.Name = "shiftTextBox";
            this.shiftTextBox.Size = new System.Drawing.Size(100, 20);
            this.shiftTextBox.TabIndex = 2;
            // 
            // hourlyPayTextBox
            // 
            this.hourlyPayTextBox.Location = new System.Drawing.Point(182, 128);
            this.hourlyPayTextBox.Name = "hourlyPayTextBox";
            this.hourlyPayTextBox.Size = new System.Drawing.Size(100, 20);
            this.hourlyPayTextBox.TabIndex = 3;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(61, 42);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(115, 13);
            this.nameLabel.TabIndex = 4;
            this.nameLabel.Text = "Enter employee name: ";
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(41, 68);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(135, 13);
            this.numberLabel.TabIndex = 5;
            this.numberLabel.Text = "Enter employee ID number:";
            // 
            // shiftLabel
            // 
            this.shiftLabel.AutoSize = true;
            this.shiftLabel.Location = new System.Drawing.Point(1, 98);
            this.shiftLabel.Name = "shiftLabel";
            this.shiftLabel.Size = new System.Drawing.Size(175, 13);
            this.shiftLabel.TabIndex = 6;
            this.shiftLabel.Text = "Enter 1 for day shift, and 2 for night:";
            // 
            // payLabel
            // 
            this.payLabel.AutoSize = true;
            this.payLabel.Location = new System.Drawing.Point(90, 128);
            this.payLabel.Name = "payLabel";
            this.payLabel.Size = new System.Drawing.Size(86, 13);
            this.payLabel.TabIndex = 7;
            this.payLabel.Text = "Enter hourly pay:";
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(130, 332);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(75, 23);
            this.enterButton.TabIndex = 8;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(470, 332);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(554, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 10;
            // 
            // nameOutLabel
            // 
            this.nameOutLabel.BackColor = System.Drawing.SystemColors.Control;
            this.nameOutLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.nameOutLabel.Location = new System.Drawing.Point(543, 38);
            this.nameOutLabel.Name = "nameOutLabel";
            this.nameOutLabel.Size = new System.Drawing.Size(89, 21);
            this.nameOutLabel.TabIndex = 11;
            // 
            // idOutLabel
            // 
            this.idOutLabel.BackColor = System.Drawing.SystemColors.Control;
            this.idOutLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.idOutLabel.Location = new System.Drawing.Point(543, 68);
            this.idOutLabel.Name = "idOutLabel";
            this.idOutLabel.Size = new System.Drawing.Size(89, 21);
            this.idOutLabel.TabIndex = 12;
            // 
            // shiftOutLabel
            // 
            this.shiftOutLabel.BackColor = System.Drawing.SystemColors.Control;
            this.shiftOutLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.shiftOutLabel.Location = new System.Drawing.Point(543, 97);
            this.shiftOutLabel.Name = "shiftOutLabel";
            this.shiftOutLabel.Size = new System.Drawing.Size(89, 21);
            this.shiftOutLabel.TabIndex = 13;
            // 
            // payOutLabel
            // 
            this.payOutLabel.BackColor = System.Drawing.SystemColors.Control;
            this.payOutLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.payOutLabel.Location = new System.Drawing.Point(543, 127);
            this.payOutLabel.Name = "payOutLabel";
            this.payOutLabel.Size = new System.Drawing.Size(89, 21);
            this.payOutLabel.TabIndex = 14;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(303, 331);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 15;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // empNameLabel
            // 
            this.empNameLabel.AutoSize = true;
            this.empNameLabel.Location = new System.Drawing.Point(444, 45);
            this.empNameLabel.Name = "empNameLabel";
            this.empNameLabel.Size = new System.Drawing.Size(38, 13);
            this.empNameLabel.TabIndex = 16;
            this.empNameLabel.Text = "Name:";
            // 
            // empIdLabel
            // 
            this.empIdLabel.AutoSize = true;
            this.empIdLabel.Location = new System.Drawing.Point(461, 72);
            this.empIdLabel.Name = "empIdLabel";
            this.empIdLabel.Size = new System.Drawing.Size(21, 13);
            this.empIdLabel.TabIndex = 17;
            this.empIdLabel.Text = "ID:";
            // 
            // empShiftLabel
            // 
            this.empShiftLabel.AutoSize = true;
            this.empShiftLabel.Location = new System.Drawing.Point(450, 102);
            this.empShiftLabel.Name = "empShiftLabel";
            this.empShiftLabel.Size = new System.Drawing.Size(31, 13);
            this.empShiftLabel.TabIndex = 18;
            this.empShiftLabel.Text = "Shift:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(422, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Hourly pay:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.empShiftLabel);
            this.Controls.Add(this.empIdLabel);
            this.Controls.Add(this.empNameLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.payOutLabel);
            this.Controls.Add(this.shiftOutLabel);
            this.Controls.Add(this.idOutLabel);
            this.Controls.Add(this.nameOutLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.payLabel);
            this.Controls.Add(this.shiftLabel);
            this.Controls.Add(this.numberLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.hourlyPayTextBox);
            this.Controls.Add(this.shiftTextBox);
            this.Controls.Add(this.idNumTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox idNumTextBox;
        private System.Windows.Forms.TextBox shiftTextBox;
        private System.Windows.Forms.TextBox hourlyPayTextBox;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.Label shiftLabel;
        private System.Windows.Forms.Label payLabel;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label nameOutLabel;
        private System.Windows.Forms.Label idOutLabel;
        private System.Windows.Forms.Label shiftOutLabel;
        private System.Windows.Forms.Label payOutLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label empNameLabel;
        private System.Windows.Forms.Label empIdLabel;
        private System.Windows.Forms.Label empShiftLabel;
        private System.Windows.Forms.Label label5;
    }
}

