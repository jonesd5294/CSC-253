﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace ExtensionMethods
{
    static class Extensions
    {
        //Reverse extension method
        public static string Reverse(this string str)
        {
            if (str.Length <= 1)
            {
                return str;
            }
            char[] chars = str.ToCharArray();
            Array.Reverse(chars);
            return new string(chars);
        }

        //Word counter method
        public static int WordCounter(this string str)
        {
            string[] userString = str.Split(new char[] { ' ', '.', '?', '!' }, StringSplitOptions.RemoveEmptyEntries);
            int wordCount = userString.Length;
            return wordCount;
        }

        //String to Array of Char method
        public static char[] CharArray(this string str)
        {           

            char[] chars = new char [str.Length];

            for (int i = 0; i < str.Length; i++)
            {
                chars[i] = str[i];
            }
            return chars;

        }

        //Short date to long date conversion
        public static string LongDate(this DateTime str)
        {
            return str.ToLongDateString();           

        }

        public static string PhoneNumber(this string str)
        {
            string phoneNum;

            char [] tokens = str.ToCharArray();

            if (tokens.Length == 10)
            {
                phoneNum = "(" + tokens[1] + tokens[2] + tokens[3] + ")" + tokens[4] + tokens[5] + tokens[6] + tokens[7] + tokens[8] + tokens[9];
            }
            else
            {
                phoneNum = "error ";
            }
            return phoneNum;
        }
    }
}
