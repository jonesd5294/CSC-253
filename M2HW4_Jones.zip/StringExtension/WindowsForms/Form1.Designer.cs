﻿
namespace WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultListBox = new System.Windows.Forms.ListBox();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.enterLabel = new System.Windows.Forms.Label();
            this.resultsLabel = new System.Windows.Forms.Label();
            this.charButton = new System.Windows.Forms.Button();
            this.dateButton = new System.Windows.Forms.Button();
            this.phoneButton = new System.Windows.Forms.Button();
            this.reverseButton = new System.Windows.Forms.Button();
            this.countButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // resultListBox
            // 
            this.resultListBox.FormattingEnabled = true;
            this.resultListBox.Location = new System.Drawing.Point(450, 90);
            this.resultListBox.Name = "resultListBox";
            this.resultListBox.Size = new System.Drawing.Size(294, 303);
            this.resultListBox.TabIndex = 0;
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(49, 90);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(260, 20);
            this.inputTextBox.TabIndex = 1;
            // 
            // enterLabel
            // 
            this.enterLabel.AutoSize = true;
            this.enterLabel.Location = new System.Drawing.Point(46, 65);
            this.enterLabel.Name = "enterLabel";
            this.enterLabel.Size = new System.Drawing.Size(114, 13);
            this.enterLabel.TabIndex = 2;
            this.enterLabel.Text = "Type your input below:";
            // 
            // resultsLabel
            // 
            this.resultsLabel.AutoSize = true;
            this.resultsLabel.Location = new System.Drawing.Point(447, 65);
            this.resultsLabel.Name = "resultsLabel";
            this.resultsLabel.Size = new System.Drawing.Size(42, 13);
            this.resultsLabel.TabIndex = 3;
            this.resultsLabel.Text = "Results";
            // 
            // charButton
            // 
            this.charButton.Location = new System.Drawing.Point(49, 159);
            this.charButton.Name = "charButton";
            this.charButton.Size = new System.Drawing.Size(75, 23);
            this.charButton.TabIndex = 4;
            this.charButton.Text = "Characters";
            this.charButton.UseVisualStyleBackColor = true;
            this.charButton.Click += new System.EventHandler(this.charButton_Click);
            // 
            // dateButton
            // 
            this.dateButton.Location = new System.Drawing.Point(49, 188);
            this.dateButton.Name = "dateButton";
            this.dateButton.Size = new System.Drawing.Size(75, 23);
            this.dateButton.TabIndex = 5;
            this.dateButton.Text = "Date";
            this.dateButton.UseVisualStyleBackColor = true;
            this.dateButton.Click += new System.EventHandler(this.dateButton_Click);
            // 
            // phoneButton
            // 
            this.phoneButton.Location = new System.Drawing.Point(49, 217);
            this.phoneButton.Name = "phoneButton";
            this.phoneButton.Size = new System.Drawing.Size(75, 23);
            this.phoneButton.TabIndex = 6;
            this.phoneButton.Text = "Phone number";
            this.phoneButton.UseVisualStyleBackColor = true;
            this.phoneButton.Click += new System.EventHandler(this.phoneButton_Click);
            // 
            // reverseButton
            // 
            this.reverseButton.Location = new System.Drawing.Point(49, 247);
            this.reverseButton.Name = "reverseButton";
            this.reverseButton.Size = new System.Drawing.Size(75, 23);
            this.reverseButton.TabIndex = 7;
            this.reverseButton.Text = "Reverse";
            this.reverseButton.UseVisualStyleBackColor = true;
            this.reverseButton.Click += new System.EventHandler(this.reverseButton_Click);
            // 
            // countButton
            // 
            this.countButton.Location = new System.Drawing.Point(49, 277);
            this.countButton.Name = "countButton";
            this.countButton.Size = new System.Drawing.Size(75, 23);
            this.countButton.TabIndex = 8;
            this.countButton.Text = "Counter";
            this.countButton.UseVisualStyleBackColor = true;
            this.countButton.Click += new System.EventHandler(this.countButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(145, 415);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(32, 415);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 10;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.countButton);
            this.Controls.Add(this.reverseButton);
            this.Controls.Add(this.phoneButton);
            this.Controls.Add(this.dateButton);
            this.Controls.Add(this.charButton);
            this.Controls.Add(this.resultsLabel);
            this.Controls.Add(this.enterLabel);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.resultListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox resultListBox;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.Label enterLabel;
        private System.Windows.Forms.Label resultsLabel;
        private System.Windows.Forms.Button charButton;
        private System.Windows.Forms.Button dateButton;
        private System.Windows.Forms.Button phoneButton;
        private System.Windows.Forms.Button reverseButton;
        private System.Windows.Forms.Button countButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}

