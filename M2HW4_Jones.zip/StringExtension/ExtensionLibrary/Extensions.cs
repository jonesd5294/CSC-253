﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionLibrary
{
    public static class Extensions
    {
        public string Reverse(string input)
        {

        }
    
    }   
}
