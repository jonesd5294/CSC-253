﻿/**
 * 10/29/2023
 * CSC 253
 * David Jones
 * This number with generate prime numbers from a list between 2 and the number entered
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static bool IsPrime(int num)
        {
            if (num < 2) return false;
            if (num == 2) return true;
            if (num % 2 == 0) return false;

            for (int i = 3; i <= Math.Sqrt(num); i += 2)
            {
                if (num % i == 0)
                {
                    return false;
                }
            }

            return true;
        }

        private void findButton_Click(object sender, EventArgs e)
        {
            int num = int.Parse(numTextBox.Text);

            if (num >= 2)
            {
                List<int> numbers = new List<int>();

                for (int i = 2; i <= num; i++)
                {
                    numbers.Add(i);
                }

                List<int> primeNumbers = numbers.FindAll(number => IsPrime(number));

                foreach(int number in primeNumbers)
                {
                    listBox1.Items.Add(number);
                }
            }
            else
            {
                MessageBox.Show("Error");
            }



        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
