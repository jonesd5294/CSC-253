﻿namespace WindowsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pricePerYearButton = new System.Windows.Forms.Button();
            this.pricePerMonthButton = new System.Windows.Forms.Button();
            this.lowHighButton = new System.Windows.Forms.Button();
            this.highLowPerYearButton = new System.Windows.Forms.Button();
            this.highLowButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.resultListBox = new System.Windows.Forms.ListBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pricePerYearButton
            // 
            this.pricePerYearButton.Location = new System.Drawing.Point(76, 101);
            this.pricePerYearButton.Name = "pricePerYearButton";
            this.pricePerYearButton.Size = new System.Drawing.Size(100, 35);
            this.pricePerYearButton.TabIndex = 0;
            this.pricePerYearButton.Text = "Price Per Year";
            this.pricePerYearButton.UseVisualStyleBackColor = true;
            this.pricePerYearButton.Click += new System.EventHandler(this.pricePerYearButton_Click);
            // 
            // pricePerMonthButton
            // 
            this.pricePerMonthButton.Location = new System.Drawing.Point(76, 156);
            this.pricePerMonthButton.Name = "pricePerMonthButton";
            this.pricePerMonthButton.Size = new System.Drawing.Size(100, 33);
            this.pricePerMonthButton.TabIndex = 1;
            this.pricePerMonthButton.Text = "Price Per Month";
            this.pricePerMonthButton.UseVisualStyleBackColor = true;
            this.pricePerMonthButton.Click += new System.EventHandler(this.pricePerMonthButton_Click);
            // 
            // lowHighButton
            // 
            this.lowHighButton.Location = new System.Drawing.Point(76, 271);
            this.lowHighButton.Name = "lowHighButton";
            this.lowHighButton.Size = new System.Drawing.Size(100, 36);
            this.lowHighButton.TabIndex = 2;
            this.lowHighButton.Text = "Lowest to Highest Price";
            this.lowHighButton.UseVisualStyleBackColor = true;
            this.lowHighButton.Click += new System.EventHandler(this.lowHighButton_Click);
            // 
            // highLowPerYearButton
            // 
            this.highLowPerYearButton.Location = new System.Drawing.Point(76, 215);
            this.highLowPerYearButton.Name = "highLowPerYearButton";
            this.highLowPerYearButton.Size = new System.Drawing.Size(100, 40);
            this.highLowPerYearButton.TabIndex = 3;
            this.highLowPerYearButton.Text = "Highest/Lowest Per Year";
            this.highLowPerYearButton.UseVisualStyleBackColor = true;
            this.highLowPerYearButton.Click += new System.EventHandler(this.highLowPerYearButton_Click);
            // 
            // highLowButton
            // 
            this.highLowButton.Location = new System.Drawing.Point(76, 326);
            this.highLowButton.Name = "highLowButton";
            this.highLowButton.Size = new System.Drawing.Size(100, 40);
            this.highLowButton.TabIndex = 4;
            this.highLowButton.Text = "Highest to Lowest Price";
            this.highLowButton.UseVisualStyleBackColor = true;
            this.highLowButton.Click += new System.EventHandler(this.highLowButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(477, 372);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // resultListBox
            // 
            this.resultListBox.FormattingEnabled = true;
            this.resultListBox.Location = new System.Drawing.Point(377, 89);
            this.resultListBox.Name = "resultListBox";
            this.resultListBox.Size = new System.Drawing.Size(265, 212);
            this.resultListBox.TabIndex = 6;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(308, 371);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 7;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.resultListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.highLowButton);
            this.Controls.Add(this.highLowPerYearButton);
            this.Controls.Add(this.lowHighButton);
            this.Controls.Add(this.pricePerMonthButton);
            this.Controls.Add(this.pricePerYearButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button pricePerYearButton;
        private System.Windows.Forms.Button pricePerMonthButton;
        private System.Windows.Forms.Button lowHighButton;
        private System.Windows.Forms.Button highLowPerYearButton;
        private System.Windows.Forms.Button highLowButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox resultListBox;
        private System.Windows.Forms.Button clearButton;
    }
}

