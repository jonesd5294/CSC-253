﻿/**
 * 11/21/2023
 * CSC 253
 * David Jones
 * this program will sort through GasPrices text file using LINQ methods
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string filePath = @"F:\C#_2\GasPrices\WindowsUI\Docs\GasPrices.txt";

        private List<GasPriceEntry> ReadPricesFromFile()
        {
            try
            {
                // Read all lines from the text file and convert them to GasPriceEntry objects
                string[] lines = File.ReadAllLines(filePath);
                return lines.Select(line =>
                {
                    string[] parts = line.Split(':');
                    return new GasPriceEntry
                    {
                        Date = DateTime.Parse(parts[0]),
                        PricePerGallon = decimal.Parse(parts[1])
                    };
                }).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading file: {ex.Message}");
                return new List<GasPriceEntry>();
            }
        }

        private void pricePerYearButton_Click(object sender, EventArgs e)
        {
            List<GasPriceEntry> gasPrices = ReadPricesFromFile();

            // LINQ query to calculate the average price per gallon per year
            var averagePricePerYear = gasPrices
                .GroupBy(entry => entry.Date.Year)
                .Select(group => new
                {
                    Year = group.Key,
                    AveragePrice = group.Average(entry => entry.PricePerGallon)
                });

            foreach (var result in averagePricePerYear)
            {
                // Add the result to the resultListBox
                resultListBox.Items.Add($"Average Price Per Gallon in {result.Year}: {result.AveragePrice:C}");
            }
        }

        // Define a class to represent a gas price entry
        private class GasPriceEntry
        {
            public DateTime Date { get; set; }
            public decimal PricePerGallon { get; set; }
        }

        private void pricePerMonthButton_Click(object sender, EventArgs e)
        {
            List<GasPriceEntry> gasPrices = ReadPricesFromFile();

            // LINQ query to calculate the average price per gallon per year for each month
            var averagePricePerMonthPerYear = gasPrices
                .GroupBy(entry => new { entry.Date.Year, entry.Date.Month })
                .Select(group => new
                {
                    Year = group.Key.Year,
                    Month = group.Key.Month,
                    AveragePrice = group.Average(entry => entry.PricePerGallon)
                });

            foreach (var result in averagePricePerMonthPerYear)
            {
                // Add the result to the resultListBox
                resultListBox.Items.Add($"Average Price Per Gallon in {result.Month:D2}-{result.Year}: {result.AveragePrice:C}");
            }
        }

        private void highLowPerYearButton_Click(object sender, EventArgs e)
        {
            List<GasPriceEntry> gasPrices = ReadPricesFromFile();

            // LINQ query to find the date and amount for the lowest and highest prices per year
            var highLowPerYear = gasPrices
                .GroupBy(entry => entry.Date.Year)
                .Select(group => new
                {
                    Year = group.Key,
                    LowestPrice = group.OrderBy(entry => entry.PricePerGallon).First(),
                    HighestPrice = group.OrderByDescending(entry => entry.PricePerGallon).First()
                });

            foreach (var result in highLowPerYear)
            {
                // Add the result to the resultListBox
                resultListBox.Items.Add(
                    $"Year: {result.Year}\n" +
                    $"Lowest Price: {result.LowestPrice.Date:D} - {result.LowestPrice.PricePerGallon:C}\n" +
                    $"Highest Price: {result.HighestPrice.Date:D} - {result.HighestPrice.PricePerGallon:C}"
                );
            }
        }

        private void lowHighButton_Click(object sender, EventArgs e)
        {
            List<GasPriceEntry> gasPrices = ReadPricesFromFile();

            // LINQ query to sort prices from low to high
            var sortedPrices = gasPrices.OrderBy(entry => entry.PricePerGallon);

            // Create a string containing the dates and prices
            string resultText = string.Join(Environment.NewLine, sortedPrices.Select(entry => $"{entry.Date:D} - {entry.PricePerGallon:C}"));

            // Specify the path for the output text file
            string outputFilePath = Path.Combine(Path.GetDirectoryName(filePath), "lowhigh.txt");

            try
            {
                // Write the sorted prices to the output text file
                File.WriteAllText(outputFilePath, resultText);

                MessageBox.Show($"Low to High prices have been written to: {outputFilePath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error writing to file: {ex.Message}");
            }
        }

        private void highLowButton_Click(object sender, EventArgs e)
        {
            List<GasPriceEntry> gasPrices = ReadPricesFromFile();

            // LINQ query to sort prices from high to low
            var sortedPrices = gasPrices.OrderByDescending(entry => entry.PricePerGallon);

            // Create a string containing the dates and prices
            string resultText = string.Join(Environment.NewLine, sortedPrices.Select(entry => $"{entry.Date:D} - {entry.PricePerGallon:C}"));

            // Specify the path for the output text file
            string outputFilePath = Path.Combine(Path.GetDirectoryName(filePath), "highlow.txt");

            try
            {
                // Write the sorted prices to the output text file
                File.WriteAllText(outputFilePath, resultText);

                MessageBox.Show($"High to Low prices have been written to: {outputFilePath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error writing to file: {ex.Message}");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear all items from the resultListBox
            resultListBox.Items.Clear();
        }
    }
}
