﻿/**
 * 9/14/2023
 * CSC 253
 * David Jones
 * This program will read a file and create a word index
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Dictionary<string, List<int>> words = new Dictionary<string, List<int>>();

        private void openButton_Click(object sender, EventArgs e)
        {
            //Try/Catch statement
            try
            {
                //Initialize StreamReader
                StreamReader inputFile;
                StreamWriter outputFile;

                //If Else statement
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    //Show file directory
                    MessageBox.Show(openFileDialog1.FileName);

                    //Assign line an int variable
                    int line = 1;

                    //Open the file and get Stream Reader object
                    inputFile = File.OpenText(openFileDialog1.FileName);

                    //While statement for end of file and processessing
                    while (!inputFile.EndOfStream)
                    {
                        string[] token = inputFile.ReadLine().Split();

                        token = RemovePunctuation(token);

                        outputFile = File.CreateText("index.txt");                        
                        
                        foreach (string word in token)
                        {
                            if (words.ContainsKey(word))
                            {
                                words[word].Add(line);
                            }
                            else
                            {
                                List<int> linenumbers = new List<int>();
                                linenumbers.Add(line);
                                words[word] = linenumbers;                                
                            }
                        }
                        line++;
                        outputFile.WriteLine(words);
                        outputFile.Close();
                    }
                    //Close inputFile
                    inputFile.Close();
                }
                //Else statement for closing open file dialog box
                else
                {
                    //You clicked cancel message
                    MessageBox.Show("You clicked cancel.");
                }

            }
            catch
            {
                //Try again message
                MessageBox.Show("Please try again.");
            }


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close program
            this.Close();
        }

        public string[] RemovePunctuation(string[] stringArray)
        {
            for (int i = 0; i < stringArray.Length; i++)
            {
                if (char.IsPunctuation(stringArray[i][stringArray[i].Length - 1]))
                {
                    stringArray[i] = stringArray[i].Remove(stringArray[i].Length - 1);
                }
            }
            return stringArray;
        }
    }
}
