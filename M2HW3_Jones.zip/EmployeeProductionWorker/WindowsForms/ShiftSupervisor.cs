﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms
{
    class ShiftSupervisor : Employee
    {
        public ShiftSupervisor()
        {
            decimal Salary = 0m;
            decimal Bonus = 0m;
        }

        public decimal Salary { get; set; }

        public decimal Bonus { get; set; }


    }
}
