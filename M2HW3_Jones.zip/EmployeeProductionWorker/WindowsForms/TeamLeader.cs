﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms
{
    class TeamLeader : ProductionWorker
    {
        public TeamLeader()
        {
            decimal MonthlyBonus;
            int TrainingHours;
            int ReqTrainingHours;
        }

         public decimal MonthylyBonus { get; set; }

         public int TrainingHours { get; set; }
            
         public int ReqTrainingHours { get; set; }
        


    }
}
