﻿/**
 * 10/24/2023
 * CSC 253
 * David Jones
 * This program will populate a tabl with the highest and lowest paying jobs from the Employee DB
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);

        }

        private void highButton_Click(object sender, EventArgs e)
        {
           decimal maxPay = (decimal)this.employeeTableAdapter.MaxPay();
            MessageBox.Show($"The highest paid employee recieves {maxPay.ToString("c")} per hour.");

        }

        private void lowButton_Click(object sender, EventArgs e)
        {
            decimal minPay = (decimal)this.employeeTableAdapter.MinPay();
            MessageBox.Show($"The lowest paid employee recieves {minPay.ToString("c")} per hour.");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
