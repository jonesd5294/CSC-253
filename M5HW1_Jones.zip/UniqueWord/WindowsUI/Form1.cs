﻿/**
 * 11/21/2023
 * CSC 253
 * David Jones
 * This program will read a text file and display all unique words using a LINQ method to eliminate repeating unique words
 */
using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace WindowsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            // Specify the path to the text file
            string filePath = @"F:\C#_2\UniqueWord\WindowsUI\Docs\text.txt";

            try
            {
                // Read all lines from the file
                string[] lines = File.ReadAllLines(filePath);

                // Concatenate all lines into a single string
                string allText = string.Join(" ", lines);

                // Split the text into words
                string[] words = allText.Split(new[] { ' ', '\t', '\n', '\r', '.', ',', ';', ':', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);

                // Use LINQ to get unique words
                var uniqueWords = words.Distinct();

                // Update the ListBox with unique words
                resultListBox.Items.Clear();
                resultListBox.Items.AddRange(uniqueWords.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}