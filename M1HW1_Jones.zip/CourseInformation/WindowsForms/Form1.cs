﻿/**
 * 9/7/2023
 * CSC 253
 * David Jones
 * This program will display course information to student: instructor, room, meeting time.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Create user input string variable
        string course;

        //Create room number dictionary with string keys and values
        Dictionary<string, string> rooms = new Dictionary<string, string>()
        {   {"CS101","3004"},
            {"CS102","4501" },
            {"CS103","6755" },
            {"NT110","1244" },
            {"CM241","1411" }};

        //Create instructor dictionary with string keys and values
        Dictionary<string, string> instructor = new Dictionary<string, string>()
        {   {"CS101","Haynes"},
            {"CS102","Alvarado" },
            {"CS103","Rich" },
            {"NT110","Burke" },
            {"CM241","Lee" }};

        //Create meeting time dictionary with string keys and values
        Dictionary<string, string> times = new Dictionary<string, string>()
        {   {"CS101","8:00 AM"},
            {"CS102","9:00 AM" },
            {"CS103","10:00 AM" },
            {"NT110","11:00 AM" },
            {"CM241","1:00 PM" }};

        private void enterButton_Click(object sender, EventArgs e)
        {
            //Assign user input to course variable
            course = courseTextBox.Text.ToUpper();
            
            //Create if else statement to locate users course and display room, instructor, meeting time, and invalid message
            if (!rooms.ContainsKey(course))
            {
                //Invalid message
                MessageBox.Show("Course is not valid.  Please re enter!");
            }
            else
            {
                //Output course information
                MessageBox.Show(course + " is located in room " + rooms[course] + " with " + instructor[course] + " at " + times[course]);
            }


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close program
            this.Close();
        }
    }
}
