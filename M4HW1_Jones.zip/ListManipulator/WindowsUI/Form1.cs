﻿/**
 * 10/29/2023
 * CSC 253
 * David Jones
 * This program will read a text file and add contents to a list that will be sorted through using RemoveAll and FindAll methods
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsUI
{
    //delegate int IntSort(int x);
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Read random.txt and add to list
        private void ReadRandom(List<int> randomList)
        {
            try
            {
                //Open text file
                StreamReader inputfile = File.OpenText(@"F:\C#_2\ListManipulator\WindowsUI\Docs\random.txt");

                //Read integers into list
                while (!inputfile.EndOfStream)
                {
                    randomList.Add(int.Parse(inputfile.ReadLine()));
                }
                //Close file
                inputfile.Close();
            }
            catch 
            {
                MessageBox.Show("Error");
            }

        }

        private void noNegButton_Click(object sender, EventArgs e)
        {
            List<int> randomList = new List<int>();

            ReadRandom(randomList);

            randomList.RemoveAll(x => x < 0);

            listBox1.DataSource = randomList;

            

        }

        private void findButton_Click(object sender, EventArgs e)
        {            

            List<int> randomList = new List<int>();

            ReadRandom(randomList);

            List<int> results = randomList.FindAll(x => x > -1 && x < 11);
            
            foreach (int num in results)
            {
                listBox2.Items.Add(num);
            }


            

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
