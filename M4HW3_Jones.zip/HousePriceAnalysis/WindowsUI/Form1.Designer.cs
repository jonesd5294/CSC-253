﻿namespace WindowsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.houseListBox = new System.Windows.Forms.ListBox();
            this.minPriceTextBox = new System.Windows.Forms.TextBox();
            this.minBedTextBox = new System.Windows.Forms.TextBox();
            this.minBathTextBox = new System.Windows.Forms.TextBox();
            this.minSqFtTextBox = new System.Windows.Forms.TextBox();
            this.priceLabel = new System.Windows.Forms.Label();
            this.bedLabel = new System.Windows.Forms.Label();
            this.bathLabel = new System.Windows.Forms.Label();
            this.sqFtLabel = new System.Windows.Forms.Label();
            this.maxPriceTextBox = new System.Windows.Forms.TextBox();
            this.maxBedTextBox = new System.Windows.Forms.TextBox();
            this.maxBathTextBox = new System.Windows.Forms.TextBox();
            this.maxSqFtTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(196, 355);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(75, 23);
            this.searchButton.TabIndex = 0;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(354, 354);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 1;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(526, 355);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // houseListBox
            // 
            this.houseListBox.FormattingEnabled = true;
            this.houseListBox.Location = new System.Drawing.Point(407, 47);
            this.houseListBox.Name = "houseListBox";
            this.houseListBox.Size = new System.Drawing.Size(382, 290);
            this.houseListBox.TabIndex = 3;
            // 
            // minPriceTextBox
            // 
            this.minPriceTextBox.Location = new System.Drawing.Point(34, 47);
            this.minPriceTextBox.Name = "minPriceTextBox";
            this.minPriceTextBox.Size = new System.Drawing.Size(100, 20);
            this.minPriceTextBox.TabIndex = 4;
            // 
            // minBedTextBox
            // 
            this.minBedTextBox.Location = new System.Drawing.Point(34, 120);
            this.minBedTextBox.Name = "minBedTextBox";
            this.minBedTextBox.Size = new System.Drawing.Size(100, 20);
            this.minBedTextBox.TabIndex = 5;
            // 
            // minBathTextBox
            // 
            this.minBathTextBox.Location = new System.Drawing.Point(34, 203);
            this.minBathTextBox.Name = "minBathTextBox";
            this.minBathTextBox.Size = new System.Drawing.Size(100, 20);
            this.minBathTextBox.TabIndex = 6;
            // 
            // minSqFtTextBox
            // 
            this.minSqFtTextBox.Location = new System.Drawing.Point(34, 286);
            this.minSqFtTextBox.Name = "minSqFtTextBox";
            this.minSqFtTextBox.Size = new System.Drawing.Size(100, 20);
            this.minSqFtTextBox.TabIndex = 7;
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.Location = new System.Drawing.Point(122, 25);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(91, 13);
            this.priceLabel.TabIndex = 8;
            this.priceLabel.Text = "Enter price range:";
            // 
            // bedLabel
            // 
            this.bedLabel.AutoSize = true;
            this.bedLabel.Location = new System.Drawing.Point(97, 87);
            this.bedLabel.Name = "bedLabel";
            this.bedLabel.Size = new System.Drawing.Size(126, 13);
            this.bedLabel.TabIndex = 9;
            this.bedLabel.Text = "Enter range of bedrooms:";
            // 
            // bathLabel
            // 
            this.bathLabel.AutoSize = true;
            this.bathLabel.Location = new System.Drawing.Point(83, 166);
            this.bathLabel.Name = "bathLabel";
            this.bathLabel.Size = new System.Drawing.Size(132, 13);
            this.bathLabel.TabIndex = 10;
            this.bathLabel.Text = "Enter range of bathrooms: ";
            // 
            // sqFtLabel
            // 
            this.sqFtLabel.AutoSize = true;
            this.sqFtLabel.Location = new System.Drawing.Point(97, 250);
            this.sqFtLabel.Name = "sqFtLabel";
            this.sqFtLabel.Size = new System.Drawing.Size(133, 13);
            this.sqFtLabel.TabIndex = 11;
            this.sqFtLabel.Text = "Enter range of square feet:";
            // 
            // maxPriceTextBox
            // 
            this.maxPriceTextBox.Location = new System.Drawing.Point(182, 47);
            this.maxPriceTextBox.Name = "maxPriceTextBox";
            this.maxPriceTextBox.Size = new System.Drawing.Size(100, 20);
            this.maxPriceTextBox.TabIndex = 12;
            // 
            // maxBedTextBox
            // 
            this.maxBedTextBox.Location = new System.Drawing.Point(182, 120);
            this.maxBedTextBox.Name = "maxBedTextBox";
            this.maxBedTextBox.Size = new System.Drawing.Size(100, 20);
            this.maxBedTextBox.TabIndex = 13;
            // 
            // maxBathTextBox
            // 
            this.maxBathTextBox.Location = new System.Drawing.Point(182, 202);
            this.maxBathTextBox.Name = "maxBathTextBox";
            this.maxBathTextBox.Size = new System.Drawing.Size(100, 20);
            this.maxBathTextBox.TabIndex = 14;
            // 
            // maxSqFtTextBox
            // 
            this.maxSqFtTextBox.Location = new System.Drawing.Point(171, 286);
            this.maxSqFtTextBox.Name = "maxSqFtTextBox";
            this.maxSqFtTextBox.Size = new System.Drawing.Size(100, 20);
            this.maxSqFtTextBox.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.maxSqFtTextBox);
            this.Controls.Add(this.maxBathTextBox);
            this.Controls.Add(this.maxBedTextBox);
            this.Controls.Add(this.maxPriceTextBox);
            this.Controls.Add(this.sqFtLabel);
            this.Controls.Add(this.bathLabel);
            this.Controls.Add(this.bedLabel);
            this.Controls.Add(this.priceLabel);
            this.Controls.Add(this.minSqFtTextBox);
            this.Controls.Add(this.minBathTextBox);
            this.Controls.Add(this.minBedTextBox);
            this.Controls.Add(this.minPriceTextBox);
            this.Controls.Add(this.houseListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.searchButton);
            this.Name = "Form1";
            this.Text = "House Price Analysis";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox houseListBox;
        private System.Windows.Forms.TextBox minPriceTextBox;
        private System.Windows.Forms.TextBox minBedTextBox;
        private System.Windows.Forms.TextBox minBathTextBox;
        private System.Windows.Forms.TextBox minSqFtTextBox;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.Label bedLabel;
        private System.Windows.Forms.Label bathLabel;
        private System.Windows.Forms.Label sqFtLabel;
        private System.Windows.Forms.TextBox maxPriceTextBox;
        private System.Windows.Forms.TextBox maxBedTextBox;
        private System.Windows.Forms.TextBox maxBathTextBox;
        private System.Windows.Forms.TextBox maxSqFtTextBox;
    }
}

