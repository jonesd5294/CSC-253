﻿/**
 * 11/5/2023
 * CSC 253
 * David Jones
 * This program will search for house variables defined by the user
 */
using HouseLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            houseList = ReadCSV(@"F:\C#_2\HousePriceAnalysis\WindowsUI\Docs\house_prices.csv");
        }

        private List<HouseData> houseList;

        private List<HouseData> ReadCSV(string filePath)
        {
            List<HouseData> houseList = new List<HouseData>();

            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] values = line.Split(',');

                    HouseData house = new HouseData
                    {
                        Price = values[0],
                        BedRooms = values[1],
                        BathRooms = values[2],
                        SquareFeet = values[3]
                    };

                    houseList.Add(house);
                }
            }

            return houseList;
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            string minPriceStr = minPriceTextBox.Text;
            string maxPriceStr = maxPriceTextBox.Text;
            string minBedroomsStr = minBedTextBox.Text;
            string maxBedroomsStr = maxBedTextBox.Text;
            string minBathroomsStr = minBathTextBox.Text;
            string maxBathroomsStr = maxBathTextBox.Text;
            string minSquareFeetStr = minSqFtTextBox.Text;
            string maxSquareFeetStr = maxSqFtTextBox.Text;

            List<HouseData> filteredHouses = houseList.FindAll(house =>
                house.Price.CompareTo(minPriceStr) >= 0 &&
                house.Price.CompareTo(maxPriceStr) <= 0 &&
                house.BedRooms.CompareTo(minBedroomsStr) >= 0 &&
                house.BedRooms.CompareTo(maxBedroomsStr) <= 0 &&
                house.BathRooms.CompareTo(minBathroomsStr) >= 0 &&
                house.BathRooms.CompareTo(maxBathroomsStr) <= 0 &&
                house.SquareFeet.CompareTo(minSquareFeetStr) >= 0 &&
                house.SquareFeet.CompareTo(maxSquareFeetStr) <= 0
            );

            houseListBox.Items.Clear();
            foreach (HouseData house in filteredHouses)
            {
                houseListBox.Items.Add($"Price: {house.Price}, Bedrooms: {house.BedRooms}, Bathrooms: {house.BathRooms}, Square Feet: {house.SquareFeet}");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            minPriceTextBox.Text = "";
            maxPriceTextBox.Text = "";
            minBedTextBox.Text = "";
            maxBedTextBox.Text = "";
            minBathTextBox.Text = "";
            maxBathTextBox.Text = "";
            minSqFtTextBox.Text = "";
            maxSqFtTextBox.Text = "";

            houseListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
