﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseLibrary
{
    public class HouseData
    {
        public string Price { get; set; }
        public string BedRooms { get; set; }
        public string BathRooms { get; set; }
        public string SquareFeet { get; set; }
    }
}
