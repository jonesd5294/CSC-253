﻿namespace WindowsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.productButton = new System.Windows.Forms.Button();
            this.textButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.inputLabel = new System.Windows.Forms.Label();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.productListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // productButton
            // 
            this.productButton.Location = new System.Drawing.Point(149, 170);
            this.productButton.Name = "productButton";
            this.productButton.Size = new System.Drawing.Size(75, 36);
            this.productButton.TabIndex = 11;
            this.productButton.Text = "Product Search";
            this.productButton.UseVisualStyleBackColor = true;
            this.productButton.Click += new System.EventHandler(this.productButton_Click);
            // 
            // textButton
            // 
            this.textButton.Location = new System.Drawing.Point(149, 247);
            this.textButton.Name = "textButton";
            this.textButton.Size = new System.Drawing.Size(75, 36);
            this.textButton.TabIndex = 10;
            this.textButton.Text = "Specified Text";
            this.textButton.UseVisualStyleBackColor = true;
            this.textButton.Click += new System.EventHandler(this.textButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(149, 336);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // inputLabel
            // 
            this.inputLabel.AutoSize = true;
            this.inputLabel.Location = new System.Drawing.Point(60, 67);
            this.inputLabel.Name = "inputLabel";
            this.inputLabel.Size = new System.Drawing.Size(164, 13);
            this.inputLabel.TabIndex = 8;
            this.inputLabel.Text = "Enter Product # / Specified Text:";
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(124, 96);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(100, 20);
            this.inputTextBox.TabIndex = 7;
            // 
            // productListBox
            // 
            this.productListBox.FormattingEnabled = true;
            this.productListBox.Location = new System.Drawing.Point(316, 78);
            this.productListBox.Name = "productListBox";
            this.productListBox.Size = new System.Drawing.Size(298, 251);
            this.productListBox.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.productListBox);
            this.Controls.Add(this.productButton);
            this.Controls.Add(this.textButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.inputLabel);
            this.Controls.Add(this.inputTextBox);
            this.Name = "Form1";
            this.Text = "Products";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button productButton;
        private System.Windows.Forms.Button textButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label inputLabel;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.ListBox productListBox;
    }
}

