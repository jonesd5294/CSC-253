﻿/**
 * 11/27/2023
 * CSC 253
 * David Jones
 * This program will search a db using LINQ to SQL searching for product # and specified text
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsUI
{
    public partial class Form1 : Form    
    {
        private readonly ProductDataContext db;

        public Form1()
        {
            InitializeComponent();

            // Create a Data Context Object
            db = new ProductDataContext();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Display all the rows in the ListBox.
            foreach (Product item in db.Products)
            {
                productListBox.Items.Add($"{item.Product_Number} - {item.Description} - {item.Units_On_Hand} - {item.Price}");
            }
        }

        private void productButton_Click(object sender, EventArgs e)
        {
            // Get the product number from the inputTextBox
            string productNumber = inputTextBox.Text.Trim();

            // LINQ to SQL query to find products by Product_Number
            var query = from product in db.Products
                        where product.Product_Number == productNumber
                        select product;

            // Update the ListBox with the search results
            productListBox.Items.Clear();
            foreach (Product item in query)
            {
                productListBox.Items.Add($"{item.Product_Number} - {item.Description} - {item.Units_On_Hand} - {item.Price}");
            }
        }

        private void textButton_Click(object sender, EventArgs e)
        {
            // Get the search text from the inputTextBox
            string searchText = inputTextBox.Text.Trim();

            // LINQ to SQL query to find products by Description containing the specified text
            var query = from product in db.Products
                        where product.Description.Contains(searchText)
                        select product;

            // Update the ListBox with the search results
            productListBox.Items.Clear();
            foreach (Product item in query)
            {
                productListBox.Items.Add($"{item.Product_Number} - {item.Description} - {item.Units_On_Hand} - {item.Price}");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
