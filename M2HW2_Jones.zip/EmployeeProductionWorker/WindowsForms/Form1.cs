﻿/**
 * 9/21/2023
 * CSC 253
 * David Jones
 * This program will display employee information held in objects
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

            private void GetProdWorkerInfo(ProductionWorker production)
            {
                //Declare variables      
                int id;
                int shift;
                decimal pay;

                //Get employee name
                production.Name = nameTextBox.Text;
                //Get employee id
                if (int.TryParse(idNumTextBox.Text, out id))
                {
                    //Assign ID to the production class
                    production.ID = id;
                    //Get user shift
                    if (int.TryParse(shiftTextBox.Text, out shift))
                    {
                        //Assign shift to Shift
                        production.Shift = shift;
                        //Get user pay
                        if (decimal.TryParse(hourlyPayTextBox.Text, out pay))
                        {
                            //Assign pay to Pay
                            production.Pay = pay;
                        }
                        else
                        {
                            //error message
                            MessageBox.Show("Entry invalid");
                        }
                    }
                    else
                    {
                        //Error message for shift
                        MessageBox.Show("Please enter a 1 or 2");
                    }
                }
                else
                {
                    //Error message for ID
                    MessageBox.Show("Invalid ID number");
                }
            }

            //Create print method
            private void PrintProdWorkInfo(ProductionWorker production)
            {
                //If statement for shift
                if(production.Shift > 0 && production.Shift < 3)
                {
                    //Declare day and night variables
                    int day = 1;
                    int night = 2;
                    //If statement for day shift and ouput
                    if(production.Shift == day)
                    {
                        nameOutLabel.Text = production.Name;
                        idOutLabel.Text = production.ID.ToString();
                        shiftOutLabel.Text = "Day";
                        payOutLabel.Text = production.Pay.ToString("c");
                    }
                    //Else if for night shift
                    else if(production.Shift == night)
                    {
                        nameOutLabel.Text = production.Name;
                        idOutLabel.Text = production.ID.ToString();
                        shiftOutLabel.Text = "Night";
                        payOutLabel.Text = production.Pay.ToString("c");
                    }
                    //Error Message
                    else
                    {
                        MessageBox.Show("Enter a valid shift 1 or 2");
                    }                
                }

            }

        private void enterButton_Click(object sender, EventArgs e)
        {
            if (prodradioButton.Checked)
            {
                //Create production worker object
                ProductionWorker myProdWorker = new ProductionWorker();
                //Get employee info call GetEmployeeInfo
                GetProdWorkerInfo(myProdWorker);
                //Call print method to display object
                PrintProdWorkInfo(myProdWorker);
            }
            else if (supradioButton.Checked)
            {
                //Create shift supervisor object
                ShiftSupervisor myShiftSup = new ShiftSupervisor();
                //Get supervisor info
                GetShiftSupInfo(myShiftSup);
                //Call print method for supervisor
                PrintSupInfo(myShiftSup);

            }
            else
            {
                MessageBox.Show("Please select a position");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            nameTextBox.Clear();
            idNumTextBox.Clear();
            shiftTextBox.Clear();
            hourlyPayTextBox.Clear();
            salaryTextBox.Clear();
            bonusTextBox.Clear();
            
        }

        private void GetShiftSupInfo(ShiftSupervisor shiftSupervisor)
        {
            //Declare variables      
            int id;
            decimal bonus;
            decimal salary;

            //Get employee name
            shiftSupervisor.Name = nameTextBox.Text;
            //Get employee id
            if (int.TryParse(idNumTextBox.Text, out id))
            {
                //Assign ID to the production class
                shiftSupervisor.ID = id;
                //Get user shift
                if (decimal.TryParse(salaryTextBox.Text, out salary))
                {
                    //Assign shift to Shift
                    shiftSupervisor.Salary = salary;
                    //Get user pay
                    if (decimal.TryParse(bonusTextBox.Text, out bonus))
                    {
                        //Assign pay to Pay
                        shiftSupervisor.Bonus = bonus;
                    }
                    else
                    {
                        //error message
                        MessageBox.Show("Entry invalid");
                    }
                }
                else
                {
                    //Error message for shift
                    MessageBox.Show("Entry invalid");
                }
            }
            else
            {
                //Error message for ID
                MessageBox.Show("Invalid ID number");
            }
        }

        private void PrintSupInfo(ShiftSupervisor shiftSupervisor)
        {
            string pay = "";
            string shift = "";
            nameOutLabel.Text = shiftSupervisor.Name;
            idOutLabel.Text = shiftSupervisor.ID.ToString();
            shiftOutLabel.Text = shift;
            payOutLabel.Text = pay;
            salaryLabel.Text = shiftSupervisor.Salary.ToString("c");
            bonusLabel.Text = shiftSupervisor.Bonus.ToString("c");            
               
        }
    }
}
