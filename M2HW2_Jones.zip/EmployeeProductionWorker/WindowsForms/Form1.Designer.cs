﻿
namespace WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.idNumTextBox = new System.Windows.Forms.TextBox();
            this.shiftTextBox = new System.Windows.Forms.TextBox();
            this.hourlyPayTextBox = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.shiftLabel = new System.Windows.Forms.Label();
            this.payLabel = new System.Windows.Forms.Label();
            this.enterButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.nameOutLabel = new System.Windows.Forms.Label();
            this.idOutLabel = new System.Windows.Forms.Label();
            this.shiftOutLabel = new System.Windows.Forms.Label();
            this.payOutLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.empNameLabel = new System.Windows.Forms.Label();
            this.empIdLabel = new System.Windows.Forms.Label();
            this.empShiftLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.salaryLabel = new System.Windows.Forms.Label();
            this.bonusLabel = new System.Windows.Forms.Label();
            this.empBonusLabel = new System.Windows.Forms.Label();
            this.empSalLabel = new System.Windows.Forms.Label();
            this.salaryTextBox = new System.Windows.Forms.TextBox();
            this.bonusTextBox = new System.Windows.Forms.TextBox();
            this.slararyInLabel = new System.Windows.Forms.Label();
            this.bonusInLabel = new System.Windows.Forms.Label();
            this.prodradioButton = new System.Windows.Forms.RadioButton();
            this.supradioButton = new System.Windows.Forms.RadioButton();
            this.positionLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(182, 39);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 0;
            // 
            // idNumTextBox
            // 
            this.idNumTextBox.Location = new System.Drawing.Point(182, 65);
            this.idNumTextBox.Name = "idNumTextBox";
            this.idNumTextBox.Size = new System.Drawing.Size(100, 20);
            this.idNumTextBox.TabIndex = 1;
            // 
            // shiftTextBox
            // 
            this.shiftTextBox.Location = new System.Drawing.Point(182, 95);
            this.shiftTextBox.Name = "shiftTextBox";
            this.shiftTextBox.Size = new System.Drawing.Size(100, 20);
            this.shiftTextBox.TabIndex = 2;
            // 
            // hourlyPayTextBox
            // 
            this.hourlyPayTextBox.Location = new System.Drawing.Point(182, 128);
            this.hourlyPayTextBox.Name = "hourlyPayTextBox";
            this.hourlyPayTextBox.Size = new System.Drawing.Size(100, 20);
            this.hourlyPayTextBox.TabIndex = 3;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(61, 42);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(115, 13);
            this.nameLabel.TabIndex = 4;
            this.nameLabel.Text = "Enter employee name: ";
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(41, 68);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(135, 13);
            this.numberLabel.TabIndex = 5;
            this.numberLabel.Text = "Enter employee ID number:";
            // 
            // shiftLabel
            // 
            this.shiftLabel.AutoSize = true;
            this.shiftLabel.Location = new System.Drawing.Point(1, 98);
            this.shiftLabel.Name = "shiftLabel";
            this.shiftLabel.Size = new System.Drawing.Size(163, 13);
            this.shiftLabel.TabIndex = 6;
            this.shiftLabel.Text = "Enter 1 for day shift or 2 for night:";
            // 
            // payLabel
            // 
            this.payLabel.AutoSize = true;
            this.payLabel.Location = new System.Drawing.Point(90, 128);
            this.payLabel.Name = "payLabel";
            this.payLabel.Size = new System.Drawing.Size(86, 13);
            this.payLabel.TabIndex = 7;
            this.payLabel.Text = "Enter hourly pay:";
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(210, 402);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(75, 23);
            this.enterButton.TabIndex = 8;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(543, 402);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(554, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 10;
            // 
            // nameOutLabel
            // 
            this.nameOutLabel.BackColor = System.Drawing.SystemColors.Control;
            this.nameOutLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.nameOutLabel.Location = new System.Drawing.Point(543, 38);
            this.nameOutLabel.Name = "nameOutLabel";
            this.nameOutLabel.Size = new System.Drawing.Size(89, 21);
            this.nameOutLabel.TabIndex = 11;
            // 
            // idOutLabel
            // 
            this.idOutLabel.BackColor = System.Drawing.SystemColors.Control;
            this.idOutLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.idOutLabel.Location = new System.Drawing.Point(543, 68);
            this.idOutLabel.Name = "idOutLabel";
            this.idOutLabel.Size = new System.Drawing.Size(89, 21);
            this.idOutLabel.TabIndex = 12;
            // 
            // shiftOutLabel
            // 
            this.shiftOutLabel.BackColor = System.Drawing.SystemColors.Control;
            this.shiftOutLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.shiftOutLabel.Location = new System.Drawing.Point(543, 97);
            this.shiftOutLabel.Name = "shiftOutLabel";
            this.shiftOutLabel.Size = new System.Drawing.Size(89, 21);
            this.shiftOutLabel.TabIndex = 13;
            // 
            // payOutLabel
            // 
            this.payOutLabel.BackColor = System.Drawing.SystemColors.Control;
            this.payOutLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.payOutLabel.Location = new System.Drawing.Point(543, 127);
            this.payOutLabel.Name = "payOutLabel";
            this.payOutLabel.Size = new System.Drawing.Size(89, 21);
            this.payOutLabel.TabIndex = 14;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(360, 402);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 15;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // empNameLabel
            // 
            this.empNameLabel.AutoSize = true;
            this.empNameLabel.Location = new System.Drawing.Point(460, 46);
            this.empNameLabel.Name = "empNameLabel";
            this.empNameLabel.Size = new System.Drawing.Size(38, 13);
            this.empNameLabel.TabIndex = 16;
            this.empNameLabel.Text = "Name:";
            // 
            // empIdLabel
            // 
            this.empIdLabel.AutoSize = true;
            this.empIdLabel.Location = new System.Drawing.Point(477, 72);
            this.empIdLabel.Name = "empIdLabel";
            this.empIdLabel.Size = new System.Drawing.Size(21, 13);
            this.empIdLabel.TabIndex = 17;
            this.empIdLabel.Text = "ID:";
            // 
            // empShiftLabel
            // 
            this.empShiftLabel.AutoSize = true;
            this.empShiftLabel.Location = new System.Drawing.Point(467, 102);
            this.empShiftLabel.Name = "empShiftLabel";
            this.empShiftLabel.Size = new System.Drawing.Size(31, 13);
            this.empShiftLabel.TabIndex = 18;
            this.empShiftLabel.Text = "Shift:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(444, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Hourly pay:";
            // 
            // salaryLabel
            // 
            this.salaryLabel.BackColor = System.Drawing.SystemColors.Control;
            this.salaryLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.salaryLabel.Location = new System.Drawing.Point(543, 157);
            this.salaryLabel.Name = "salaryLabel";
            this.salaryLabel.Size = new System.Drawing.Size(89, 21);
            this.salaryLabel.TabIndex = 20;
            // 
            // bonusLabel
            // 
            this.bonusLabel.BackColor = System.Drawing.SystemColors.Control;
            this.bonusLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bonusLabel.Location = new System.Drawing.Point(543, 192);
            this.bonusLabel.Name = "bonusLabel";
            this.bonusLabel.Size = new System.Drawing.Size(89, 21);
            this.bonusLabel.TabIndex = 21;
            // 
            // empBonusLabel
            // 
            this.empBonusLabel.AutoSize = true;
            this.empBonusLabel.Location = new System.Drawing.Point(435, 200);
            this.empBonusLabel.Name = "empBonusLabel";
            this.empBonusLabel.Size = new System.Drawing.Size(75, 13);
            this.empBonusLabel.TabIndex = 22;
            this.empBonusLabel.Text = "Annual bonus:";
            // 
            // empSalLabel
            // 
            this.empSalLabel.AutoSize = true;
            this.empSalLabel.Location = new System.Drawing.Point(435, 165);
            this.empSalLabel.Name = "empSalLabel";
            this.empSalLabel.Size = new System.Drawing.Size(73, 13);
            this.empSalLabel.TabIndex = 23;
            this.empSalLabel.Text = "Annual salary:";
            // 
            // salaryTextBox
            // 
            this.salaryTextBox.Location = new System.Drawing.Point(182, 165);
            this.salaryTextBox.Name = "salaryTextBox";
            this.salaryTextBox.Size = new System.Drawing.Size(100, 20);
            this.salaryTextBox.TabIndex = 24;
            // 
            // bonusTextBox
            // 
            this.bonusTextBox.Location = new System.Drawing.Point(182, 200);
            this.bonusTextBox.Name = "bonusTextBox";
            this.bonusTextBox.Size = new System.Drawing.Size(100, 20);
            this.bonusTextBox.TabIndex = 25;
            // 
            // slararyInLabel
            // 
            this.slararyInLabel.AutoSize = true;
            this.slararyInLabel.Location = new System.Drawing.Point(76, 168);
            this.slararyInLabel.Name = "slararyInLabel";
            this.slararyInLabel.Size = new System.Drawing.Size(100, 13);
            this.slararyInLabel.TabIndex = 26;
            this.slararyInLabel.Text = "Enter annual salary:";
            // 
            // bonusInLabel
            // 
            this.bonusInLabel.AutoSize = true;
            this.bonusInLabel.Location = new System.Drawing.Point(74, 207);
            this.bonusInLabel.Name = "bonusInLabel";
            this.bonusInLabel.Size = new System.Drawing.Size(102, 13);
            this.bonusInLabel.TabIndex = 27;
            this.bonusInLabel.Text = "Enter annual bonus:";
            // 
            // prodradioButton
            // 
            this.prodradioButton.AutoSize = true;
            this.prodradioButton.Location = new System.Drawing.Point(438, 318);
            this.prodradioButton.Name = "prodradioButton";
            this.prodradioButton.Size = new System.Drawing.Size(114, 17);
            this.prodradioButton.TabIndex = 28;
            this.prodradioButton.TabStop = true;
            this.prodradioButton.Text = "Production Worker";
            this.prodradioButton.UseVisualStyleBackColor = true;
            // 
            // supradioButton
            // 
            this.supradioButton.AutoSize = true;
            this.supradioButton.Location = new System.Drawing.Point(229, 318);
            this.supradioButton.Name = "supradioButton";
            this.supradioButton.Size = new System.Drawing.Size(99, 17);
            this.supradioButton.TabIndex = 29;
            this.supradioButton.TabStop = true;
            this.supradioButton.Text = "Shift Supervisor";
            this.supradioButton.UseVisualStyleBackColor = true;
            // 
            // positionLabel
            // 
            this.positionLabel.AutoSize = true;
            this.positionLabel.Location = new System.Drawing.Point(325, 280);
            this.positionLabel.Name = "positionLabel";
            this.positionLabel.Size = new System.Drawing.Size(118, 13);
            this.positionLabel.TabIndex = 30;
            this.positionLabel.Text = "Please select a position";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.positionLabel);
            this.Controls.Add(this.supradioButton);
            this.Controls.Add(this.prodradioButton);
            this.Controls.Add(this.bonusInLabel);
            this.Controls.Add(this.slararyInLabel);
            this.Controls.Add(this.bonusTextBox);
            this.Controls.Add(this.salaryTextBox);
            this.Controls.Add(this.empSalLabel);
            this.Controls.Add(this.empBonusLabel);
            this.Controls.Add(this.bonusLabel);
            this.Controls.Add(this.salaryLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.empShiftLabel);
            this.Controls.Add(this.empIdLabel);
            this.Controls.Add(this.empNameLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.payOutLabel);
            this.Controls.Add(this.shiftOutLabel);
            this.Controls.Add(this.idOutLabel);
            this.Controls.Add(this.nameOutLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.payLabel);
            this.Controls.Add(this.shiftLabel);
            this.Controls.Add(this.numberLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.hourlyPayTextBox);
            this.Controls.Add(this.shiftTextBox);
            this.Controls.Add(this.idNumTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Name = "Form1";
            this.Text = "Employee Info";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox idNumTextBox;
        private System.Windows.Forms.TextBox shiftTextBox;
        private System.Windows.Forms.TextBox hourlyPayTextBox;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.Label shiftLabel;
        private System.Windows.Forms.Label payLabel;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label nameOutLabel;
        private System.Windows.Forms.Label idOutLabel;
        private System.Windows.Forms.Label shiftOutLabel;
        private System.Windows.Forms.Label payOutLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label empNameLabel;
        private System.Windows.Forms.Label empIdLabel;
        private System.Windows.Forms.Label empShiftLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label salaryLabel;
        private System.Windows.Forms.Label bonusLabel;
        private System.Windows.Forms.Label empBonusLabel;
        private System.Windows.Forms.Label empSalLabel;
        private System.Windows.Forms.TextBox salaryTextBox;
        private System.Windows.Forms.TextBox bonusTextBox;
        private System.Windows.Forms.Label slararyInLabel;
        private System.Windows.Forms.Label bonusInLabel;
        private System.Windows.Forms.RadioButton prodradioButton;
        private System.Windows.Forms.RadioButton supradioButton;
        private System.Windows.Forms.Label positionLabel;
    }
}

