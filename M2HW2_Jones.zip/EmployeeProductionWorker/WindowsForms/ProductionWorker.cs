﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms
{
    class ProductionWorker : Employee
    {
        public ProductionWorker()
        {
            int Shift = 0;
            decimal Pay = 0m;
        }

        public int Shift { get; set; }
        
        public decimal Pay { get; set; }


    }
}
