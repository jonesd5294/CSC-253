﻿/**
 * 9/10/2023
 * CSC 253
 * David Jones
 * This program will read and encrypt a file.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Dictionary<char, char> codes = new Dictionary<char, char>()
        { { 'A', '!' }, { 'a', 'q' }, { 'B', 'a' }, { 'b', 'z' }, { 'C', '@' }, { 'c', 'w' },
          { 'D', 's' }, { 'd', 'x' }, { 'E', '#' }, { 'e', 'c' }, { 'F', 'd' }, { 'f', 'e' },
          { 'G', '$' }, { 'g', 'r' }, { 'H', 'f' }, { 'h', 'v' }, { 'I', '%' }, { 'i', 't' },
          { 'J', 'g' }, { 'j', 'b' }, { 'K', '^' }, { 'k', 'y' }, { 'L', 'h' }, { 'l', 'n' },
          { 'M', '&' }, { 'm', 'u' }, { 'N', 'j' }, { 'n', 'm' }, { 'O', '*' }, { 'o', 'i' },
          { 'P', 'k' }, { 'p', '<' }, { 'Q', '(' }, { 'q', 'o' }, { 'R', 'l' }, { 'r', '>' },
          { 'S', ')' }, { 's', 'p' }, { 'T', ':' }, { 't', '/' }, { 'U', '-' }, { 'u', '[' },
          { 'V', '"' }, { 'v', '+' }, { 'W', ']' }, { 'w', '\\'}, { 'X', ';' }, { 'x', '.'},
          { 'Y', ',' }, { 'y', '|' }, { 'Z', '=' }, { 'z', '_' }, { ' ', '~' }, { ',', 'X' },
          { '.', '2' }, { '?', '3' }, { '\n', '\t' }, { '\t', ' ' } };

        Dictionary<char, char> decodes = new Dictionary<char, char>()
        { { '!', 'A' }, { 'q', 'a' }, { 'a', 'B' }, { 'z', 'b' }, { '@', 'C' }, { 'w', 'c' },
          { 's', 'D' }, { 'x', 'd' }, { '#', 'E' }, { 'c', 'e' }, { 'd', 'F' }, { 'e', 'f' },
          { '$', 'G' }, { 'r', 'g' }, { 'f', 'H' }, { 'v', 'h' }, { '%', 'I' }, { 't', 'i' },
          { 'g', 'J' }, { 'b', 'j' }, { '^', 'K' }, { 'y', 'k' }, { 'h', 'L' }, { 'n', 'l' },
          { '&', 'M' }, { 'u', 'm' }, { 'j', 'N' }, { 'm', 'n' }, { '*', 'O' }, { 'i', 'o' },
          { 'k', 'P' }, { '<', 'p' }, { '(', 'Q' }, { 'o', 'q' }, { 'l', 'R' }, { '>', 'r' },
          { ')', 'S' }, { 'p', 's' }, { ':', 'T' }, { '/', 't' }, { '-', 'U' }, { '[', 'u' },
          { '"', 'V' }, { '+', 'v' }, { ']', 'W' }, { '\\', 'w'}, { ';', 'X' }, { '.', 'x'},
          { ',', 'Y' }, { '|', 'y' }, { '=', 'Z' }, { '_', 'z' }, { '~', ' ' }, { 'X', ',' },
          { '2', '.' }, { '3', '?' }, { '\t', '\n' }, { ' ', '\t' } };

        private void encryptButton_Click(object sender, EventArgs e)
        {           

            //Try catch method
            try
            {
                //Initialize StreamReader
                StreamReader inputFile;
                StreamWriter outputFile;
                
                //If Else statement
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    //Open the file and get Stream Reader object
                    inputFile = File.OpenText(openFileDialog1.FileName);

                    //Declare char code variable for reader
                    string code;

                    //While statement for end of file and processessing
                    while (!inputFile.EndOfStream)
                    {
                        //Read file and assign char to variable                    
                        code = inputFile.ReadLine();

                        //Declare StreamWriter variable
                        outputFile = File.CreateText("Decrypt.txt");

                        string outSentence = "";

                        //Compare keys to file characters
                        foreach (char character in code)
                        {
                            if (codes.ContainsKey(character))
                            {
                                char loopChar = codes[character];

                                outSentence = outSentence + loopChar.ToString();
                            }

                        }

                        outputFile.WriteLine(outSentence);
                        //Close outputFile
                        outputFile.Close();

                    }
                    //Close inputFile
                    inputFile.Close();

                }
                //Else statement for closing open file dialog box
                else
                {
                    //You clicked cancel message
                    MessageBox.Show("You clicked cancel.");
                }               
                
            }
            catch
            {
                //Try again message
                MessageBox.Show("Please try again.");
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close program
            this.Close();
        }

        private void decryptButton_Click(object sender, EventArgs e)
        {           

            //Try catch method
            try
            {             
                //Initialize StreamReader
                StreamReader inputFile;
                StreamWriter outputFile;

                //If Else statement
                if (openFileDialog2.ShowDialog() == DialogResult.OK)
                {
                    //Open the file and get Stream Reader object
                    inputFile = File.OpenText(openFileDialog2.FileName);

                    //Declare char code variable for reader
                    string code;

                    //While statement for end of file and processessing
                    while (!inputFile.EndOfStream)
                    {
                        //Read file and assign char to variable                    
                        code = inputFile.ReadLine();

                        //Declare StreamWriter variable
                        outputFile = File.CreateText("Decrypt.txt");

                        string outSentence = "";

                        //Compare keys to file characters
                        foreach (char character in code)
                        {
                            if (decodes.ContainsKey(character))
                            {
                                char loopChar = decodes[character];

                                outSentence = outSentence + loopChar.ToString();
                            }

                        }

                        outputFile.WriteLine(outSentence);
                        //Close outputFile
                        outputFile.Close();

                    }
                    //Close inputFile
                    inputFile.Close();

                }
                //Else statement for closing open file dialog box
                else
                {
                    //You clicked cancel message
                    MessageBox.Show("You clicked cancel.");
                }

            }
            catch
            {
                //Try again message
                MessageBox.Show("Please try again.");
            }

        }


    
    }
}
