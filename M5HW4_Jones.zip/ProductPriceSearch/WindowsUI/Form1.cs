﻿/**
 *11/27/2023
 *CSC 253
 *David Jones
 *This program will search a product db given user min and max price range
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsUI
{
    public partial class Form1 : Form
    {
        private readonly ProductDataContext db;

        public Form1()
        {
            InitializeComponent();
            
            db = new ProductDataContext();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            var products = db.Products.OrderBy(p => p.Units_On_Hand);
            foreach (Product item in products)
            {
                productListBox.Items.Add($"{item.Product_Number} - {item.Description} - {item.Units_On_Hand} - {item.Price}");
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {            
            decimal minValue, maxValue;
            if (!decimal.TryParse(minTextBox.Text, out minValue) || !decimal.TryParse(maxTextBox.Text, out maxValue))
            {
                MessageBox.Show("Please enter valid numeric values for min and max.");
                return;
            }
            
            var query = from product in db.Products
                        where product.Price >= minValue && product.Price <= maxValue
                        orderby product.Units_On_Hand 
                        select product;
            
            productListBox.Items.Clear();
            foreach (Product item in query)
            {
                productListBox.Items.Add($"{item.Product_Number} - {item.Description} - {item.Units_On_Hand} - {item.Price}");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
