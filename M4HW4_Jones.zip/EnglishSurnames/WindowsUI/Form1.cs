﻿/**
 * 11/5/2023
 * CSC 253
 * David Jones
 * This program will search through a list of names based of search criteria given from the user.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ReadSurnames(List<string> surnamesList)
        {
            try
            {
                // Open text file
                StreamReader inputFile = File.OpenText(@"F:\C#_2\EnglishSurnames\WindowsUI\Docs\surnames.txt");

                // Read surnames into list
                while (!inputFile.EndOfStream)
                {
                    surnamesList.Add(inputFile.ReadLine());
                }
                // Close file
                inputFile.Close();
            }
            catch
            {
                MessageBox.Show("Error");
            }
        }

        private void longButton_Click(object sender, EventArgs e)
        {
            // Get the specified length from the longerTextBox
            int specifiedLength;
            if (!int.TryParse(longerTextBox.Text, out specifiedLength))
            {
                MessageBox.Show("Please enter a valid integer for the specified length.");
                return;
            }

            List<string> surnamesList = new List<string>();

            // Call the ReadSurnames method to populate the list
            ReadSurnames(surnamesList);

            // Find surnames longer than the specified length
            List<string> filteredSurnames = new List<string>();
            foreach (string surname in surnamesList)
            {
                if (surname.Length > specifiedLength)
                {
                    filteredSurnames.Add(surname);
                }
            }

            // Display filtered surnames
            nameListBox.Items.Clear();
            foreach (string surname in filteredSurnames)
            {
                nameListBox.Items.Add(surname);
            }
        }

        private void shortButton_Click(object sender, EventArgs e)
        {
            // Get the specified length from the shortTextBox
            int specifiedLength;
            if (!int.TryParse(shortTextBox.Text, out specifiedLength))
            {
                MessageBox.Show("Please enter a valid integer for the specified length.");
                return;
            }

            List<string> surnamesList = new List<string>();

            // Call the ReadSurnames method to populate the list
            ReadSurnames(surnamesList);

            // Find surnames shorter than the specified length
            List<string> filteredSurnames = new List<string>();
            foreach (string surname in surnamesList)
            {
                if (surname.Length < specifiedLength)
                {
                    filteredSurnames.Add(surname);
                }
            }

            // Display filtered surnames
            nameListBox.Items.Clear();
            foreach (string surname in filteredSurnames)
            {
                nameListBox.Items.Add(surname);
            }
        }

        private void specButton_Click(object sender, EventArgs e)
        {
            // Get the specified prefix from the specTextBox
            string specifiedPrefix = specTextBox.Text;

            List<string> surnamesList = new List<string>();

            // Call the ReadSurnames method to populate the list
            ReadSurnames(surnamesList);

            // Filter surnames that start with the specified prefix
            List<string> filteredSurnames = surnamesList.FindAll(surname =>
                surname.StartsWith(specifiedPrefix, StringComparison.OrdinalIgnoreCase));

            // Display filtered surnames
            nameListBox.Items.Clear();
            foreach (string surname in filteredSurnames)
            {
                nameListBox.Items.Add(surname);
            }
        }

        private void nameButton_Click(object sender, EventArgs e)
        {
            // Get the specified name from the nameTextBox
            string specifiedName = nameTextBox.Text;

            List<string> surnamesList = new List<string>();

            // Call the ReadSurnames method to populate the list
            ReadSurnames(surnamesList);

            // Find the exact name in the list
            string foundName = surnamesList.Find(surname =>
                string.Equals(surname, specifiedName, StringComparison.OrdinalIgnoreCase));

            // If found, add it to the nameListBox
            if (foundName != null)
            {
                nameListBox.Items.Add(foundName);
            }
            else
            {
                MessageBox.Show($"Exact name '{specifiedName}' not found in the list.");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            longerTextBox.Clear();
            shortTextBox.Clear();
            specTextBox.Clear();
            nameTextBox.Clear();    

            nameListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
