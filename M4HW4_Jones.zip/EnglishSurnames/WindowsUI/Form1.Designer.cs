﻿namespace WindowsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameListBox = new System.Windows.Forms.ListBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.nameButton = new System.Windows.Forms.Button();
            this.longLabel = new System.Windows.Forms.Label();
            this.longerTextBox = new System.Windows.Forms.TextBox();
            this.shortTextBox = new System.Windows.Forms.TextBox();
            this.shortLabel = new System.Windows.Forms.Label();
            this.specTextBox = new System.Windows.Forms.TextBox();
            this.specLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.specButton = new System.Windows.Forms.Button();
            this.shortButton = new System.Windows.Forms.Button();
            this.longButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameListBox
            // 
            this.nameListBox.FormattingEnabled = true;
            this.nameListBox.Location = new System.Drawing.Point(426, 41);
            this.nameListBox.Name = "nameListBox";
            this.nameListBox.Size = new System.Drawing.Size(244, 251);
            this.nameListBox.TabIndex = 0;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(446, 359);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(307, 359);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 2;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // nameButton
            // 
            this.nameButton.Location = new System.Drawing.Point(162, 291);
            this.nameButton.Name = "nameButton";
            this.nameButton.Size = new System.Drawing.Size(75, 23);
            this.nameButton.TabIndex = 3;
            this.nameButton.Text = "Search";
            this.nameButton.UseVisualStyleBackColor = true;
            this.nameButton.Click += new System.EventHandler(this.nameButton_Click);
            // 
            // longLabel
            // 
            this.longLabel.AutoSize = true;
            this.longLabel.Location = new System.Drawing.Point(48, 78);
            this.longLabel.Name = "longLabel";
            this.longLabel.Size = new System.Drawing.Size(153, 13);
            this.longLabel.TabIndex = 4;
            this.longLabel.Text = "Search for a name longer than:";
            // 
            // longerTextBox
            // 
            this.longerTextBox.Location = new System.Drawing.Point(207, 75);
            this.longerTextBox.Name = "longerTextBox";
            this.longerTextBox.Size = new System.Drawing.Size(100, 20);
            this.longerTextBox.TabIndex = 5;
            // 
            // shortTextBox
            // 
            this.shortTextBox.Location = new System.Drawing.Point(207, 135);
            this.shortTextBox.Name = "shortTextBox";
            this.shortTextBox.Size = new System.Drawing.Size(100, 20);
            this.shortTextBox.TabIndex = 6;
            // 
            // shortLabel
            // 
            this.shortLabel.AutoSize = true;
            this.shortLabel.Location = new System.Drawing.Point(45, 138);
            this.shortLabel.Name = "shortLabel";
            this.shortLabel.Size = new System.Drawing.Size(156, 13);
            this.shortLabel.TabIndex = 7;
            this.shortLabel.Text = "Search for a name shorter than:";
            // 
            // specTextBox
            // 
            this.specTextBox.Location = new System.Drawing.Point(207, 198);
            this.specTextBox.Name = "specTextBox";
            this.specTextBox.Size = new System.Drawing.Size(100, 20);
            this.specTextBox.TabIndex = 8;
            // 
            // specLabel
            // 
            this.specLabel.AutoSize = true;
            this.specLabel.Location = new System.Drawing.Point(19, 201);
            this.specLabel.Name = "specLabel";
            this.specLabel.Size = new System.Drawing.Size(182, 13);
            this.specLabel.TabIndex = 9;
            this.specLabel.Text = "Search specified string of characters:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(207, 265);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 10;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(75, 268);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(126, 13);
            this.nameLabel.TabIndex = 11;
            this.nameLabel.Text = "Enter name to search for:";
            // 
            // specButton
            // 
            this.specButton.Location = new System.Drawing.Point(162, 232);
            this.specButton.Name = "specButton";
            this.specButton.Size = new System.Drawing.Size(75, 23);
            this.specButton.TabIndex = 12;
            this.specButton.Text = "Search";
            this.specButton.UseVisualStyleBackColor = true;
            this.specButton.Click += new System.EventHandler(this.specButton_Click);
            // 
            // shortButton
            // 
            this.shortButton.Location = new System.Drawing.Point(162, 168);
            this.shortButton.Name = "shortButton";
            this.shortButton.Size = new System.Drawing.Size(75, 23);
            this.shortButton.TabIndex = 13;
            this.shortButton.Text = "Search";
            this.shortButton.UseVisualStyleBackColor = true;
            this.shortButton.Click += new System.EventHandler(this.shortButton_Click);
            // 
            // longButton
            // 
            this.longButton.Location = new System.Drawing.Point(162, 101);
            this.longButton.Name = "longButton";
            this.longButton.Size = new System.Drawing.Size(75, 23);
            this.longButton.TabIndex = 14;
            this.longButton.Text = "Search";
            this.longButton.UseVisualStyleBackColor = true;
            this.longButton.Click += new System.EventHandler(this.longButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.longButton);
            this.Controls.Add(this.shortButton);
            this.Controls.Add(this.specButton);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.specLabel);
            this.Controls.Add(this.specTextBox);
            this.Controls.Add(this.shortLabel);
            this.Controls.Add(this.shortTextBox);
            this.Controls.Add(this.longerTextBox);
            this.Controls.Add(this.longLabel);
            this.Controls.Add(this.nameButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.nameListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox nameListBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button nameButton;
        private System.Windows.Forms.Label longLabel;
        private System.Windows.Forms.TextBox longerTextBox;
        private System.Windows.Forms.TextBox shortTextBox;
        private System.Windows.Forms.Label shortLabel;
        private System.Windows.Forms.TextBox specTextBox;
        private System.Windows.Forms.Label specLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Button specButton;
        private System.Windows.Forms.Button shortButton;
        private System.Windows.Forms.Button longButton;
    }
}

